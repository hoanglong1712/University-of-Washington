## Assignment Instructions
Details about this assignment can be found [on the course webpage](https://courses.cs.washington.edu/courses/cse455/25wi/assignments/) for Winter '25, under Assignment 0.


Please examine `collect_submission.ipynb` for detailed submission instructions.